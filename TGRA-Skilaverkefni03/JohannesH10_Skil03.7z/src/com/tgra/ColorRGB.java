package com.tgra;

/**
 * Created by Johannes Gunnar Heidarsson on 1.10.2014.
 */
public class ColorRGB {
    public float r;
    public float g;
    public float b;

    public ColorRGB(float r, float g, float b){
        this.r = r;
        this.g = g;
        this.b = b;
    }
}
