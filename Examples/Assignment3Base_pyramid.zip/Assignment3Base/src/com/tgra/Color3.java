package com.tgra;

public class Color3 {

	public float r;
	public float g;
	public float b;
	
	public Color3(float rr, float gg, float bb)
	{
		r = rr;
		g = gg;
		b = bb;
	}
	
	public void set(float rr, float gg, float bb)
	{
		r = rr;
		g = gg;
		b = bb;
	}
	
}
